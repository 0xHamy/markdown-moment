# Section 1: Deep Dive

Advanced topics start here.

![Deep Dive Image](../media/vance.jpeg)