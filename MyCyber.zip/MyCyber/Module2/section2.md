# Section 2: Applications

Apply what you've learned.
