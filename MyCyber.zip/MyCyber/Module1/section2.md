# Section 2: Concepts

- Concept 1
- Concept 2