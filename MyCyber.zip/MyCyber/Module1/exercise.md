# Exercise for Module 1

1. Summarize Section 1.
2. List concepts from Section 2.
